-- CONQUEST after_import.lua
-- Add in dicom.ini:
-- ImportConverter0 = lua:after_import.lua

local json = require("json")

local ERP_BASE_URL = os.getenv("ERP_BASE_URL") or "https://YOUR-ERP-URL.replit.app"
local INTERNAL_API_KEY = os.getenv("INTERNAL_API_KEY") or "CHANGE_ME"

function post_json(url, body)
  local command = string.format(
    'curl -s -X POST "%s" -H "Content-Type: application/json" -H "Authorization: Bearer %s" -d "%s"',
    url,
    INTERNAL_API_KEY,
    body:gsub('"', '\\"')
  )
  local handle = io.popen(command)
  local result = handle:read("*a")
  handle:close()
  return result
end

-- CONQUEST exposes DICOM object fields through Data in many Lua hooks.
-- Adjust field access depending on your Conquest Lua version.
local payload = {
  studyId = Data.StudyInstanceUID or "",
  studyInstanceUID = Data.StudyInstanceUID or "",
  accessionNumber = Data.AccessionNumber or "",
  patientId = Data.PatientID or "",
  patientName = Data.PatientName or "",
  age = Data.PatientAge or "",
  sex = Data.PatientSex or "",
  modality = Data.Modality or "",
  studyDescription = Data.StudyDescription or "",
  studyDate = Data.StudyDate or "",
  referringDoctor = Data.ReferringPhysicianName or "",
  sourcePacs = "CONQUEST",
  sourceAeTitle = "ORTHANC2",
  sourceIp = "",
  receivedAt = os.date("!%Y-%m-%dT%H:%M:%SZ"),
  dicomMetadata = {
    StudyInstanceUID = Data.StudyInstanceUID or "",
    AccessionNumber = Data.AccessionNumber or "",
    PatientID = Data.PatientID or "",
    PatientName = Data.PatientName or "",
    Modality = Data.Modality or "",
    StudyDescription = Data.StudyDescription or ""
  }
}

local body = json.encode(payload)
local url = ERP_BASE_URL .. "/api/internal/radiology/studies"
local response = post_json(url, body)

print("ERP study intake response: " .. tostring(response))
