import express, { Request, Response, NextFunction } from "express";

export const radiologyRouter = express.Router();

const INTERNAL_API_KEY = process.env.INTERNAL_API_KEY || "";

function requireInternalApiKey(req: Request, res: Response, next: NextFunction) {
  const auth = req.headers.authorization || "";
  const token = auth.startsWith("Bearer ") ? auth.slice(7) : "";
  if (!INTERNAL_API_KEY || token !== INTERNAL_API_KEY) {
    return res.status(401).json({ success: false, error: "Unauthorized internal API request" });
  }
  next();
}

radiologyRouter.use("/internal", requireInternalApiKey);

/**
 * Replace these with your actual DB adapter calls.
 * The function names are intentionally simple for easy Replit integration.
 */
const db = {
  async findPatientById(patientId: string) {
    return null as any;
  },
  async findWorklistByUIDOrAccession(studyInstanceUID?: string, accessionNumber?: string) {
    return null as any;
  },
  async upsertWorklist(payload: any) {
    return { id: "WORKLIST_ID_PLACEHOLDER", ...payload };
  },
  async insertAuditLog(payload: any) {
    return payload;
  },
  async updateWorklistStatus(payload: any) {
    return payload;
  },
  async listWorklist(query: any) {
    return [];
  },
  async listLogs(query: any) {
    return [];
  },
  async insertPacsLog(payload: any) {
    return payload;
  },
  async getSettings() {
    return [];
  },
  async upsertSetting(payload: any) {
    return payload;
  },
  async listModalities() {
    return [];
  },
  async upsertModality(payload: any) {
    return payload;
  },
};

function normalizeStudyPayload(input: any) {
  return {
    studyId: input.studyId || input.study_id || input.StudyID || input.studyInstanceUID || input.StudyInstanceUID,
    studyInstanceUID: input.studyInstanceUID || input.StudyInstanceUID,
    accessionNumber: input.accessionNumber || input.AccessionNumber,
    patientId: input.patientId || input.PatientID,
    patientName: input.patientName || input.PatientName,
    age: input.age || input.PatientAge,
    sex: input.sex || input.PatientSex,
    modality: input.modality || input.Modality,
    studyDescription: input.studyDescription || input.StudyDescription,
    studyDate: input.studyDate || input.StudyDate,
    reportDate: input.reportDate,
    referringDoctor: input.referringDoctor || input.ReferringPhysicianName,
    weasisUrl: input.weasisUrl,
    sourcePacs: input.sourcePacs || "CONQUEST",
    sourceAeTitle: input.sourceAeTitle || input.aeTitle || input.CallingAETitle,
    sourceIp: input.sourceIp || input.ipAddress,
    receivedAt: input.receivedAt || new Date().toISOString(),
    dicomMetadata: input.dicomMetadata || input,
  };
}

async function logAudit(action: string, payload: any, status = "SUCCESS", source = "ERP_API") {
  await db.insertAuditLog({
    studyId: payload.studyId,
    studyInstanceUID: payload.studyInstanceUID,
    accessionNumber: payload.accessionNumber,
    action,
    source,
    status,
    message: payload.message || action,
    metadata: payload,
    createdAt: new Date().toISOString(),
  });
}

/**
 * GET patient contact
 */
radiologyRouter.get("/internal/patients/:id/contact", async (req, res) => {
  const patient = await db.findPatientById(req.params.id);
  if (!patient) {
    return res.status(404).json({ success: false, error: "Patient not found" });
  }

  res.json({
    success: true,
    patientId: patient.patientId || patient.id,
    patientName: patient.name || patient.patientName,
    age: patient.age,
    sex: patient.sex,
    email: patient.email || null,
    phone: patient.mobile || patient.phone || null,
  });
});

/**
 * CONQUEST Lua direct study intake
 */
radiologyRouter.post("/internal/radiology/studies", async (req, res) => {
  const study = normalizeStudyPayload(req.body);

  if (!study.studyInstanceUID && !study.accessionNumber) {
    await logAudit("STUDY_RECEIVED", study, "FAILED", "CONQUEST_LUA_IMPORT");
    return res.status(400).json({
      success: false,
      error: "studyInstanceUID or accessionNumber is required",
    });
  }

  const existing = await db.findWorklistByUIDOrAccession(study.studyInstanceUID, study.accessionNumber);
  if (existing) {
    await logAudit("STUDY_RECEIVED", study, "DUPLICATE", "CONQUEST_LUA_IMPORT");
    return res.json({
      success: true,
      worklistId: existing.id,
      matchedPatient: existing.patientMatchStatus === "MATCHED",
      existingStudy: true,
    });
  }

  const patient = study.patientId ? await db.findPatientById(study.patientId) : null;
  const patientMatchStatus = patient ? "MATCHED" : "UNMATCHED";

  const created = await db.upsertWorklist({
    ...study,
    patientMatchStatus,
    status: "STUDY_RECEIVED",
    aiDraftStatus: "NOT_STARTED",
    deliveryStatus: "NOT_READY",
    createdAt: new Date().toISOString(),
    updatedAt: new Date().toISOString(),
  });

  await logAudit("STUDY_RECEIVED", { ...study, worklistId: created.id }, patient ? "SUCCESS" : "UNMATCHED", "CONQUEST_LUA_IMPORT");

  res.json({
    success: true,
    worklistId: created.id,
    matchedPatient: !!patient,
    existingStudy: false,
  });
});

/**
 * DICOM event endpoint
 */
radiologyRouter.post("/internal/radiology/dicom-event", async (req, res) => {
  const allowed = [
    "STUDY_RECEIVED",
    "SERIES_RECEIVED",
    "STUDY_COMPLETED",
    "STUDY_DELETED",
    "EXPORT_COMPLETED",
    "IMPORT_FAILED",
    "MATCH_FAILED",
  ];

  const eventType = req.body.eventType;
  if (!allowed.includes(eventType)) {
    return res.status(400).json({ success: false, error: "Invalid eventType" });
  }

  await logAudit(eventType, req.body, eventType.includes("FAILED") ? "FAILED" : "SUCCESS", req.body.sourcePacs || "CONQUEST");

  if (eventType === "STUDY_COMPLETED") {
    await db.updateWorklistStatus({
      studyInstanceUID: req.body.studyInstanceUID,
      accessionNumber: req.body.accessionNumber,
      status: "STUDY_RECEIVED",
    });
  }

  res.json({ success: true });
});

/**
 * AI draft endpoint - template fallback.
 */
radiologyRouter.post("/internal/radiology/ai-draft", async (req, res) => {
  const {
    modality,
    studyDescription,
    clinicalHistory,
    rawFindings,
    templateId,
    patientName,
    age,
    sex,
    referringDoctor,
  } = req.body;

  const title = studyDescription || templateId || `${modality || "RADIOLOGY"} STUDY`;

  const technique = buildTechnique(modality, title);
  const findings = buildFindings(modality, rawFindings);
  const impression = buildImpression(rawFindings);
  const recommendation = "Please correlate with clinical findings.";

  const formattedReportText = `
${patientName || ""}    AGE/SEX: ${age || ""}/${sex || ""}    REFD. BY: ${referringDoctor || ""}

========================================

${title.toUpperCase()}

TECHNIQUE:
${technique}

========================================

OBSERVATION / FINDINGS:
${findings}

IMPRESSION:
${impression.map((i: string) => `• ${i}`).join("\n")}

RECOMMENDATION:
${recommendation}
`.trim();

  const formattedReportHtml = `
<div class="report">
  <p><strong>${patientName || ""}</strong> &nbsp; <strong>AGE/SEX:</strong> ${age || ""}/${sex || ""} &nbsp; <strong>REFD. BY:</strong> ${referringDoctor || ""}</p>
  <hr style="border:2px solid #000;" />
  <h2 style="text-align:center;text-decoration:underline;"><strong>${title.toUpperCase()}</strong></h2>
  <h3><u>TECHNIQUE</u></h3>
  <p>${escapeHtml(technique)}</p>
  <hr style="border:2px solid #000;" />
  <h3><u>OBSERVATION / FINDINGS</u></h3>
  <p>${escapeHtml(findings).replace(/\n/g, "<br/>")}</p>
  <h3><u>IMPRESSION</u></h3>
  <ul>${impression.map((i: string) => `<li>${escapeHtml(i)}</li>`).join("")}</ul>
  <h3><u>RECOMMENDATION</u></h3>
  <p>${recommendation}</p>
</div>`;

  await logAudit("AI_DRAFT_GENERATED", req.body, "SUCCESS", "AI");

  res.json({
    success: true,
    title,
    technique,
    findings,
    impression,
    recommendation,
    formattedReportText,
    formattedReportHtml,
  });
});

function buildTechnique(modality: string, title: string) {
  const m = (modality || "").toUpperCase();
  if (m.includes("MR") || title.toUpperCase().includes("MRI")) {
    return "MRI has been performed on 3 Tesla MRI scanner with multi-sequence, multi-planar acquisition using standard sequences and studied in axial, sagittal and coronal planes.";
  }
  if (m.includes("CT")) {
    return "CT study has been performed using standard protocol with multiplanar reconstruction.";
  }
  if (m.includes("US")) {
    return "Ultrasound examination has been performed using high-frequency probe as clinically appropriate.";
  }
  if (m.includes("XR") || m.includes("DX") || title.toUpperCase().includes("X-RAY")) {
    return "Digital radiograph has been obtained in standard projections.";
  }
  return "Study has been performed using standard protocol.";
}

function buildFindings(modality: string, raw: string) {
  const text = raw || "No specific abnormality provided. Radiologist to edit findings after image review.";
  const m = (modality || "").toUpperCase();
  if (m.includes("MR")) {
    return `BRAIN / REGION OF INTEREST:\n${text}\n\nVENTRICULAR SYSTEM / CSF SPACES:\nTo be reviewed.\n\nMIDLINE STRUCTURES:\nTo be reviewed.`;
  }
  if (m.includes("CT")) {
    return `CT FINDINGS:\n${text}\n\nNo additional finding is generated automatically. Radiologist to verify.`;
  }
  if (m.includes("US")) {
    return `ULTRASOUND FINDINGS:\n${text}\n\nOrgan-wise details to be edited by radiologist.`;
  }
  return text;
}

function buildImpression(raw: string) {
  if (!raw) return ["Draft impression pending radiologist findings."];
  return raw
    .split(/[.;\n]/)
    .map((x) => x.trim())
    .filter(Boolean)
    .slice(0, 6);
}

function escapeHtml(value: string) {
  return String(value || "")
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

/**
 * Worklist, dashboard, logs, settings
 */
radiologyRouter.get("/internal/radiology/worklist", async (req, res) => {
  res.json({ success: true, items: await db.listWorklist(req.query) });
});

radiologyRouter.post("/internal/radiology/report-status", async (req, res) => {
  await db.updateWorklistStatus(req.body);
  await logAudit("REPORT_STATUS_UPDATED", req.body, "SUCCESS", "ERP_API");
  res.json({ success: true });
});

radiologyRouter.get("/internal/radiology/templates", async (_req, res) => {
  res.json({
    success: true,
    templates: [
      "MRI Brain Plain",
      "MRI Brain Contrast",
      "MRI LS Spine",
      "MRI Cervical Spine",
      "CT Brain",
      "X-Ray Chest",
      "USG Abdomen",
    ],
  });
});

radiologyRouter.get("/internal/radiology/pacs-dashboard", async (_req, res) => {
  res.json({
    success: true,
    studiesToday: 0,
    onlineModalities: 0,
    failedImports: 0,
    unmatchedStudies: 0,
    pendingReports: 0,
    criticalStudies: 0,
    recentEvents: [],
    unmatchedStudyList: [],
    failedImportList: [],
    pendingReportList: [],
  });
});

radiologyRouter.get("/internal/radiology/pacs-logs", async (req, res) => {
  res.json({ success: true, items: await db.listLogs(req.query) });
});

radiologyRouter.post("/internal/radiology/pacs-logs", async (req, res) => {
  const log = await db.insertPacsLog(req.body);
  res.json({ success: true, log });
});

radiologyRouter.get("/internal/radiology/pacs-settings", async (_req, res) => {
  res.json({ success: true, items: await db.getSettings() });
});

radiologyRouter.post("/internal/radiology/pacs-settings", async (req, res) => {
  res.json({ success: true, item: await db.upsertSetting(req.body) });
});

radiologyRouter.get("/internal/radiology/modalities", async (_req, res) => {
  res.json({ success: true, items: await db.listModalities() });
});

radiologyRouter.post("/internal/radiology/modalities", async (req, res) => {
  res.json({ success: true, item: await db.upsertModality(req.body) });
});
