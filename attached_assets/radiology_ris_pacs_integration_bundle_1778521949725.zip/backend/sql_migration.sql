CREATE TABLE IF NOT EXISTS radiology_worklist (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  study_id TEXT,
  study_instance_uid TEXT UNIQUE,
  accession_number TEXT,
  patient_id TEXT,
  patient_name TEXT,
  age TEXT,
  sex TEXT,
  modality TEXT,
  study_description TEXT,
  study_date TEXT,
  report_date TEXT,
  referring_doctor TEXT,
  status TEXT DEFAULT 'STUDY_RECEIVED',
  delivery_status TEXT DEFAULT 'NOT_READY',
  priority TEXT DEFAULT 'ROUTINE',
  critical_flag BOOLEAN DEFAULT FALSE,
  weasis_url TEXT,
  source_pacs TEXT,
  source_ae_title TEXT,
  source_ip TEXT,
  received_at TIMESTAMPTZ DEFAULT now(),
  dicom_metadata JSONB DEFAULT '{}'::jsonb,
  patient_match_status TEXT DEFAULT 'UNMATCHED',
  report_id TEXT,
  ai_draft_status TEXT DEFAULT 'NOT_STARTED',
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_radiology_worklist_accession ON radiology_worklist(accession_number);
CREATE INDEX IF NOT EXISTS idx_radiology_worklist_patient_id ON radiology_worklist(patient_id);
CREATE INDEX IF NOT EXISTS idx_radiology_worklist_status ON radiology_worklist(status);
CREATE INDEX IF NOT EXISTS idx_radiology_worklist_modality ON radiology_worklist(modality);

CREATE TABLE IF NOT EXISTS radiology_audit_log (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  study_id TEXT,
  study_instance_uid TEXT,
  accession_number TEXT,
  action TEXT NOT NULL,
  source TEXT,
  status TEXT,
  message TEXT,
  metadata JSONB DEFAULT '{}'::jsonb,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS pacs_settings (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  key TEXT NOT NULL,
  value TEXT,
  category TEXT,
  is_secret BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now(),
  UNIQUE(key, category)
);

CREATE TABLE IF NOT EXISTS dicom_modalities (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  machine_name TEXT NOT NULL,
  modality TEXT,
  ae_title TEXT,
  ip_address TEXT,
  port INTEGER,
  location TEXT,
  auto_send_enabled BOOLEAN DEFAULT TRUE,
  auto_pull_enabled BOOLEAN DEFAULT FALSE,
  is_active BOOLEAN DEFAULT TRUE,
  last_connection_status TEXT,
  last_seen_at TIMESTAMPTZ,
  last_error TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS pacs_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  log_type TEXT,
  severity TEXT,
  source TEXT,
  event_type TEXT,
  message TEXT,
  study_instance_uid TEXT,
  accession_number TEXT,
  patient_id TEXT,
  modality TEXT,
  payload JSONB DEFAULT '{}'::jsonb,
  error_stack TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);
