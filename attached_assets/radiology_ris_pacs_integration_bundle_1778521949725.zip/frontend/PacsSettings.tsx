import React, { useEffect, useState } from "react";

export default function PacsSettings() {
  const [settings, setSettings] = useState<any[]>([]);
  const [modalities, setModalities] = useState<any[]>([]);

  async function load() {
    const headers = { Authorization: `Bearer ${localStorage.getItem("INTERNAL_API_KEY") || ""}` };
    setSettings((await (await fetch("/api/internal/radiology/pacs-settings", { headers })).json()).items || []);
    setModalities((await (await fetch("/api/internal/radiology/modalities", { headers })).json()).items || []);
  }

  useEffect(() => { load(); }, []);

  return (
    <div className="p-4 space-y-6">
      <h1 className="text-2xl font-bold">PACS / DICOM Settings</h1>

      <section className="rounded-2xl border p-4">
        <h2 className="font-bold text-lg">CONQUEST PACS</h2>
        <p>AE Title: ORTHANC2</p>
        <p>DICOM Port: 5680</p>
        <p>Web Port: 8086</p>
      </section>

      <section className="rounded-2xl border p-4">
        <h2 className="font-bold text-lg">Modalities</h2>
        <table className="w-full text-sm">
          <thead><tr><th>Machine</th><th>Modality</th><th>AE</th><th>IP</th><th>Port</th><th>Status</th></tr></thead>
          <tbody>
            {modalities.map((m) => (
              <tr key={m.id} className="border-t">
                <td>{m.machineName}</td><td>{m.modality}</td><td>{m.aeTitle}</td>
                <td>{m.ipAddress}</td><td>{m.port}</td><td>{m.lastConnectionStatus}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </div>
  );
}
