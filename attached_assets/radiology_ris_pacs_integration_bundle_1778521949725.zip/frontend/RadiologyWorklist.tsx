import React, { useEffect, useState } from "react";

type Study = {
  id: string;
  patientName: string;
  age?: string;
  sex?: string;
  modality: string;
  studyDescription: string;
  accessionNumber?: string;
  status: string;
  weasisUrl?: string;
};

export default function RadiologyWorklist() {
  const [items, setItems] = useState<Study[]>([]);
  const [loading, setLoading] = useState(false);

  async function load() {
    setLoading(true);
    const res = await fetch("/api/internal/radiology/worklist", {
      headers: { Authorization: `Bearer ${localStorage.getItem("INTERNAL_API_KEY") || ""}` },
    });
    const data = await res.json();
    setItems(data.items || []);
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  return (
    <div className="p-4 space-y-4">
      <div className="flex items-center justify-between">
        <h1 className="text-2xl font-bold">Radiology PACS Worklist</h1>
        <button className="px-3 py-2 rounded-xl shadow" onClick={load}>Refresh</button>
      </div>

      {loading && <p>Loading...</p>}

      <div className="overflow-auto rounded-2xl border">
        <table className="w-full text-sm">
          <thead>
            <tr className="text-left">
              <th className="p-2">Patient</th>
              <th className="p-2">Age/Sex</th>
              <th className="p-2">Modality</th>
              <th className="p-2">Study</th>
              <th className="p-2">Accession</th>
              <th className="p-2">Status</th>
              <th className="p-2">Actions</th>
            </tr>
          </thead>
          <tbody>
            {items.map((s) => (
              <tr key={s.id} className="border-t">
                <td className="p-2 font-medium">{s.patientName}</td>
                <td className="p-2">{s.age}/{s.sex}</td>
                <td className="p-2">{s.modality}</td>
                <td className="p-2">{s.studyDescription}</td>
                <td className="p-2">{s.accessionNumber}</td>
                <td className="p-2">{s.status}</td>
                <td className="p-2 space-x-2">
                  {s.weasisUrl && <a className="underline" href={s.weasisUrl}>Open Weasis</a>}
                  <a className="underline" href={`/radiology/report/${s.id}`}>Report</a>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
