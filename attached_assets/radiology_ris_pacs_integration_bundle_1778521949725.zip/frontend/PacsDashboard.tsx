import React, { useEffect, useState } from "react";

export default function PacsDashboard() {
  const [data, setData] = useState<any>({});

  async function load() {
    const res = await fetch("/api/internal/radiology/pacs-dashboard", {
      headers: { Authorization: `Bearer ${localStorage.getItem("INTERNAL_API_KEY") || ""}` },
    });
    setData(await res.json());
  }

  useEffect(() => { load(); }, []);

  const cards = [
    ["Studies Today", data.studiesToday],
    ["Online Modalities", data.onlineModalities],
    ["Failed Imports", data.failedImports],
    ["Unmatched Studies", data.unmatchedStudies],
    ["Pending Reports", data.pendingReports],
    ["Critical Studies", data.criticalStudies],
  ];

  return (
    <div className="p-4 space-y-4">
      <h1 className="text-2xl font-bold">Live PACS Dashboard</h1>
      <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
        {cards.map(([k, v]) => (
          <div className="rounded-2xl border p-4 shadow" key={String(k)}>
            <div className="text-sm opacity-70">{k}</div>
            <div className="text-3xl font-bold">{v ?? 0}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
