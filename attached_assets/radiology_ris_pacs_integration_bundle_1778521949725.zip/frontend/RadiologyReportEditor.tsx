import React, { useState } from "react";

export default function RadiologyReportEditor() {
  const [rawFindings, setRawFindings] = useState("");
  const [reportHtml, setReportHtml] = useState("");
  const [impression, setImpression] = useState("");
  const [critical, setCritical] = useState(false);

  async function generateDraft() {
    const res = await fetch("/api/internal/radiology/ai-draft", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${localStorage.getItem("INTERNAL_API_KEY") || ""}`,
      },
      body: JSON.stringify({
        modality: "MRI",
        studyDescription: "MRI BRAIN",
        rawFindings,
        templateId: "MRI Brain Plain",
      }),
    });
    const data = await res.json();
    setReportHtml(data.formattedReportHtml || "");
    setImpression((data.impression || []).join("\n"));
  }

  async function saveFinal() {
    // Replit should map these values from real loaded study.
    await fetch("/api/patient-reports", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        patientId: "PATIENT_ID",
        testId: "RADIOLOGY_TEST_ID",
        title: "MRI BRAIN",
        type: "radiology",
        body: reportHtml,
        impression,
        isCritical: critical,
      }),
    });
    alert("Final report saved.");
  }

  return (
    <div className="p-4 grid grid-cols-1 lg:grid-cols-2 gap-4">
      <div className="space-y-4">
        <h1 className="text-2xl font-bold">Radiology Report Editor</h1>
        <textarea
          className="w-full min-h-40 border rounded-xl p-3"
          placeholder="Type raw findings: Fazekas grade 2, senile changes..."
          value={rawFindings}
          onChange={(e) => setRawFindings(e.target.value)}
        />
        <button className="px-4 py-2 rounded-xl shadow" onClick={generateDraft}>Generate AI Draft</button>

        <textarea
          className="w-full min-h-32 border rounded-xl p-3"
          placeholder="Impression"
          value={impression}
          onChange={(e) => setImpression(e.target.value)}
        />

        <label className="flex gap-2">
          <input type="checkbox" checked={critical} onChange={(e) => setCritical(e.target.checked)} />
          Critical report
        </label>

        <button className="px-4 py-2 rounded-xl shadow font-bold" onClick={saveFinal}>Save Final Report</button>
      </div>

      <div className="border rounded-2xl p-4">
        <h2 className="font-bold mb-2">Preview</h2>
        <div dangerouslySetInnerHTML={{ __html: reportHtml }} />
      </div>
    </div>
  );
}
