import os
import time
import json
import queue
import logging
import requests
from pathlib import Path

# Optional DICOM sender:
# pip install pynetdicom pydicom requests watchdog
try:
    from pynetdicom import AE
    from pynetdicom.sop_class import CTImageStorage, MRImageStorage, SecondaryCaptureImageStorage, UltrasoundImageStorage, DigitalXRayImageStorageForPresentation
    import pydicom
except Exception:
    AE = None
    pydicom = None

CONFIG_PATH = os.environ.get("HOPE_PACS_AGENT_CONFIG", "agent_config.json")

logging.basicConfig(
    filename="hope_pacs_agent.log",
    level=logging.INFO,
    format="%(asctime)s %(levelname)s %(message)s"
)

DEFAULT_CONFIG = {
    "erpBaseUrl": "https://YOUR-ERP-URL.replit.app",
    "internalApiKey": "CHANGE_ME",
    "conquestAeTitle": "ORTHANC2",
    "conquestIp": "127.0.0.1",
    "conquestPort": 5680,
    "localAeTitle": "HOPEAGENT",
    "pollIntervalSeconds": 10,
    "hotFolders": [
        {"name": "MRI", "path": "D:/DICOM-INBOX/MRI", "modality": "MR"},
        {"name": "CT", "path": "D:/DICOM-INBOX/CT", "modality": "CT"},
        {"name": "XRAY", "path": "D:/DICOM-INBOX/XRAY", "modality": "DX"},
        {"name": "USG", "path": "D:/DICOM-INBOX/USG", "modality": "US"}
    ]
}

def load_config():
    if not Path(CONFIG_PATH).exists():
        Path(CONFIG_PATH).write_text(json.dumps(DEFAULT_CONFIG, indent=2))
    return json.loads(Path(CONFIG_PATH).read_text())

def send_to_conquest(dicom_file, cfg):
    if AE is None or pydicom is None:
        logging.warning("pynetdicom/pydicom not installed. Skipping DICOM send.")
        return False

    ds = pydicom.dcmread(str(dicom_file))
    ae = AE(ae_title=cfg["localAeTitle"])

    for sop in [CTImageStorage, MRImageStorage, SecondaryCaptureImageStorage, UltrasoundImageStorage, DigitalXRayImageStorageForPresentation]:
        ae.add_requested_context(sop)

    assoc = ae.associate(cfg["conquestIp"], int(cfg["conquestPort"]), ae_title=cfg["conquestAeTitle"])
    if not assoc.is_established:
        logging.error("Could not associate with CONQUEST")
        return False

    status = assoc.send_c_store(ds)
    assoc.release()
    return bool(status and status.Status in [0x0000, 0xB000])

def notify_erp_from_dicom(dicom_file, cfg):
    if pydicom is None:
        return
    ds = pydicom.dcmread(str(dicom_file), stop_before_pixels=True)
    payload = {
        "studyId": str(getattr(ds, "StudyInstanceUID", "")),
        "studyInstanceUID": str(getattr(ds, "StudyInstanceUID", "")),
        "accessionNumber": str(getattr(ds, "AccessionNumber", "")),
        "patientId": str(getattr(ds, "PatientID", "")),
        "patientName": str(getattr(ds, "PatientName", "")),
        "age": str(getattr(ds, "PatientAge", "")),
        "sex": str(getattr(ds, "PatientSex", "")),
        "modality": str(getattr(ds, "Modality", "")),
        "studyDescription": str(getattr(ds, "StudyDescription", "")),
        "studyDate": str(getattr(ds, "StudyDate", "")),
        "sourcePacs": "HOPE_PACS_AGENT",
        "sourceAeTitle": cfg["localAeTitle"],
        "dicomMetadata": {
            "SOPInstanceUID": str(getattr(ds, "SOPInstanceUID", "")),
            "SeriesInstanceUID": str(getattr(ds, "SeriesInstanceUID", "")),
            "StudyInstanceUID": str(getattr(ds, "StudyInstanceUID", "")),
        }
    }
    url = cfg["erpBaseUrl"].rstrip("/") + "/api/internal/radiology/studies"
    requests.post(url, json=payload, headers={"Authorization": f"Bearer {cfg['internalApiKey']}"}, timeout=15)

def heartbeat(cfg):
    try:
        url = cfg["erpBaseUrl"].rstrip("/") + "/api/internal/radiology/agent-heartbeat"
        requests.post(url, json={"agent": "HopePacsAgent", "status": "ONLINE"}, headers={"Authorization": f"Bearer {cfg['internalApiKey']}"}, timeout=5)
    except Exception as e:
        logging.warning(f"Heartbeat failed: {e}")

def main():
    cfg = load_config()
    processed = set()

    while True:
        heartbeat(cfg)
        for folder in cfg["hotFolders"]:
            path = Path(folder["path"])
            path.mkdir(parents=True, exist_ok=True)

            for file in path.rglob("*"):
                if not file.is_file() or file in processed:
                    continue
                try:
                    ok = send_to_conquest(file, cfg)
                    if ok:
                        notify_erp_from_dicom(file, cfg)
                        logging.info(f"Imported {file}")
                    else:
                        logging.warning(f"Failed to send {file}")
                    processed.add(file)
                except Exception as e:
                    logging.exception(f"Error processing {file}: {e}")

        time.sleep(int(cfg["pollIntervalSeconds"]))

if __name__ == "__main__":
    main()
