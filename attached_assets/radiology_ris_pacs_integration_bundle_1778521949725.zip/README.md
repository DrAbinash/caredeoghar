# Radiology RIS/PACS Integration Bundle

This bundle is designed to be merged into an existing Replit ERP.

It includes:
- Express/Nest-style backend route logic
- SQL schema/migration draft
- React frontend page stubs
- CONQUEST Lua after-import hook
- Windows PACS Agent starter using Python + pynetdicom
- Test payloads
- Replit integration command

## Main Architecture

Machines → CONQUEST PACS → CONQUEST Lua Hook → ERP Internal API → RIS Worklist → Weasis → AI Report Editor → Final Report

## Integration Order

1. Merge database schema.
2. Mount backend routes.
3. Add frontend routes/pages.
4. Configure INTERNAL_API_KEY.
5. Add CONQUEST Lua hook.
6. Test with sample payload.
7. Deploy Windows PACS Agent only if machine auto-send is not available.
