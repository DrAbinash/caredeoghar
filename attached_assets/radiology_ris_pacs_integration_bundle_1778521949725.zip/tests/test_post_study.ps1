$headers = @{
  "Authorization" = "Bearer YOUR_INTERNAL_API_KEY"
  "Content-Type" = "application/json"
}

$body = @{
  studyId = "TEST001"
  patientId = "PAT001"
  patientName = "TEST PATIENT"
  age = "45"
  sex = "M"
  modality = "MRI"
  studyDescription = "MRI BRAIN WITH CONTRAST"
  studyDate = "2026-05-11"
  accessionNumber = "ACC-TEST-001"
  studyInstanceUID = "1.2.840.TEST001"
  sourcePacs = "CONQUEST"
  sourceAeTitle = "ORTHANC2"
  sourceIp = "127.0.0.1"
  weasisUrl = "weasis://test"
} | ConvertTo-Json

Invoke-RestMethod -Uri "https://YOUR-ERP-URL.replit.app/api/internal/radiology/studies" -Method POST -Headers $headers -Body $body
