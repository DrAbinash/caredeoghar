import React, { useEffect, useState } from "react";
import VoiceDictationButton from "./VoiceDictationButton";

export default function RadiologyReportGenerator() {
  const [templates, setTemplates] = useState<any[]>([]);
  const [templateId, setTemplateId] = useState("MRI_BRAIN_PLAIN");
  const [rawFindings, setRawFindings] = useState("");
  const [previewHtml, setPreviewHtml] = useState("");
  const [keyImages, setKeyImages] = useState<any[]>([]);

  useEffect(() => { fetch("/api/internal/radiology/report-templates").then(r=>r.json()).then(d=>setTemplates(d.templates || [])); }, []);

  async function uploadImage(file: File) {
    const fd = new FormData();
    fd.append("image", file);
    const res = await fetch("/api/internal/radiology/report-generator/key-images", { method: "POST", body: fd });
    const data = await res.json();
    if (data.item) setKeyImages([...keyImages, data.item]);
  }

  async function generate() {
    const res = await fetch("/api/internal/radiology/report-generator/generate", {
      method: "POST",
      headers: {"Content-Type":"application/json"},
      body: JSON.stringify({ templateId, rawFindings, keyImages })
    });
    const data = await res.json();
    setPreviewHtml(data.formattedReportHtml || "");
  }

  return (
    <div className="p-4 grid grid-cols-1 xl:grid-cols-2 gap-4">
      <div className="space-y-4">
        <h1 className="text-2xl font-bold">Radiology Report Generator</h1>
        <select className="border rounded-xl p-2 w-full" value={templateId} onChange={(e)=>setTemplateId(e.target.value)}>
          {templates.map(t => <option key={t.templateId} value={t.templateId}>{t.modality} — {t.studyName}</option>)}
        </select>

        <div>
          <div className="flex justify-between mb-2"><b>Raw Findings</b><VoiceDictationButton onInsert={(t)=>setRawFindings(v=>v+t)} /></div>
          <textarea className="border rounded-xl p-3 w-full min-h-36" value={rawFindings} onChange={(e)=>setRawFindings(e.target.value)} />
        </div>

        <div className="border rounded-xl p-3">
          <b>Key Images</b>
          <input type="file" accept="image/png,image/jpeg,image/webp" onChange={(e)=>e.target.files?.[0] && uploadImage(e.target.files[0])} />
          <div className="grid grid-cols-2 gap-2 mt-2">
            {keyImages.map((img, i) => <img key={i} src={img.imageUrl} className="max-h-40 object-contain border" />)}
          </div>
        </div>

        <button className="px-4 py-2 rounded-xl border" onClick={generate}>Generate Draft</button>
        <button className="px-4 py-2 rounded-xl border" onClick={()=>window.print()}>Print</button>
      </div>
      <div className="border rounded-xl p-4 bg-white">
        <h2 className="font-bold">Preview</h2>
        <div dangerouslySetInnerHTML={{ __html: previewHtml }} />
      </div>
    </div>
  );
}
