import React, { useRef, useState } from "react";

export default function VoiceDictationButton({ onInsert }: { onInsert: (text: string) => void }) {
  const [listening, setListening] = useState(false);
  const recognitionRef = useRef<any>(null);

  function start() {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
    if (!SpeechRecognition) return alert("Use Chrome/Edge for voice dictation.");
    const recognition = new SpeechRecognition();
    recognition.lang = "en-IN";
    recognition.continuous = true;
    recognition.interimResults = false;
    recognition.onresult = async (event: any) => {
      let transcript = "";
      for (let i = event.resultIndex; i < event.results.length; i++) transcript += event.results[i][0].transcript + " ";
      const r = await fetch("/api/internal/radiology/voice-cleanup", { method: "POST", headers: {"Content-Type":"application/json"}, body: JSON.stringify({ rawTranscript: transcript }) });
      const data = await r.json();
      onInsert((data.cleanedText || transcript) + " ");
    };
    recognition.onend = () => setListening(false);
    recognition.start();
    recognitionRef.current = recognition;
    setListening(true);
  }

  function stop() {
    recognitionRef.current?.stop?.();
    setListening(false);
  }

  return <button type="button" className="px-3 py-2 rounded-xl border" onClick={listening ? stop : start}>{listening ? "Stop Voice" : "🎙️ Voice"}</button>;
}
