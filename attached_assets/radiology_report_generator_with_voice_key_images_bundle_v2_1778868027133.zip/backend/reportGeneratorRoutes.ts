// Replit integration stub.
// Merge into existing API router and replace placeholder db functions.

import express from "express";
import multer from "multer";
import path from "path";
import fs from "fs";
import { radiologyReportTemplates } from "./reportTemplates";

export const reportGeneratorRouter = express.Router();

const uploadDir = path.join(process.cwd(), "uploads", "radiology-key-images");
fs.mkdirSync(uploadDir, { recursive: true });

const upload = multer({
  dest: uploadDir,
  limits: { fileSize: 10 * 1024 * 1024 }
});

function cleanupVoiceText(raw: string) {
  return String(raw || "")
    .replace(/\bcomma\b/gi, ",")
    .replace(/\bfull stop\b/gi, ".")
    .replace(/\bnew line\b/gi, "\n")
    .replace(/\bcolon\b/gi, ":")
    .replace(/\bflair\b/gi, "FLAIR")
    .replace(/\bdwi\b/gi, "DWI")
    .replace(/\badc\b/gi, "ADC")
    .replace(/\bswi\b/gi, "SWI")
    .replace(/\bfazekas\b/gi, "Fazekas")
    .replace(/\s+/g, " ")
    .replace(/\s+([,.])/g, "$1")
    .trim();
}

function escapeHtml(value: string) {
  return String(value || "").replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
}

function buildReportHtml(input: any, template: any, keyImages: any[]) {
  const raw = input.rawFindings || "";
  const impression = raw ? raw.split(/[.;\n]/).map((x: string) => x.trim()).filter(Boolean).slice(0, 6) : ["Draft impression pending radiologist verification."];
  const firstSection = template.sections?.[0] || "FINDINGS";

  const imagesHtml = keyImages?.length ? `
    <h3><u>KEY IMAGES</u></h3>
    <div style="display:grid;grid-template-columns:repeat(2,1fr);gap:10px;">
      ${keyImages.filter((x:any)=>x.includeInReport!==false).map((img:any)=>`
        <figure style="margin:0;text-align:center;">
          <img src="${escapeHtml(img.imageUrl)}" style="max-width:100%;max-height:220px;object-fit:contain;border:1px solid #999;" />
          <figcaption style="font-size:11px;">${escapeHtml(img.caption || "")}</figcaption>
        </figure>
      `).join("")}
    </div>` : "";

  return `
<div style="font-family:Arial;font-size:13px;line-height:1.35;">
  <p><strong>NAME: ${escapeHtml(input.patientName || "")} &nbsp; AGE/SEX: ${escapeHtml(input.age || "")}/${escapeHtml(input.sex || "")} &nbsp; UHID: ${escapeHtml(input.patientId || "")} &nbsp; REFD. BY: ${escapeHtml(input.referringDoctor || "")}</strong></p>
  <hr style="border:2px solid #000;" />
  <h2 style="text-align:center;text-decoration:underline;font-size:16px;"><strong>${escapeHtml(template.studyName)}</strong></h2>
  <h3><u>TECHNIQUE</u></h3>
  <p>${escapeHtml(template.technique)}</p>
  <hr style="border:2px solid #000;" />
  <h3><u>FINDINGS / OBSERVATION</u></h3>
  <p><strong><u>${escapeHtml(firstSection)}</u></strong><br/>${escapeHtml(raw).replaceAll("\n", "<br/>")}</p>
  ${imagesHtml}
  <h3><u>IMPRESSION</u></h3>
  <ul>${impression.map((x:string)=>`<li>${escapeHtml(x)}</li>`).join("")}</ul>
  <h3><u>RECOMMENDATION</u></h3>
  <p>${escapeHtml(input.recommendation || "Please correlate with clinical findings.")}</p>
</div>`.trim();
}

reportGeneratorRouter.get("/internal/radiology/report-templates", async (_req, res) => {
  res.json({ success: true, templates: Object.values(radiologyReportTemplates) });
});

reportGeneratorRouter.post("/internal/radiology/voice-cleanup", async (req, res) => {
  const cleanedText = cleanupVoiceText(req.body.rawTranscript || "");
  res.json({ success: true, cleanedText, structuredPoints: cleanedText.split(/[.;\n]/).map((x: string)=>x.trim()).filter(Boolean) });
});

reportGeneratorRouter.post("/internal/radiology/report-generator/generate", async (req, res) => {
  const template = (radiologyReportTemplates as any)[req.body.templateId] || Object.values(radiologyReportTemplates)[0];
  const html = buildReportHtml(req.body, template, req.body.keyImages || []);
  res.json({ success: true, title: template.studyName, formattedReportHtml: html, formattedReportText: html.replace(/<[^>]*>/g, " ") });
});

reportGeneratorRouter.post("/internal/radiology/report-generator/key-images", upload.single("image"), async (req, res) => {
  if (!req.file) return res.status(400).json({ success: false, error: "Image file required" });
  const ext = path.extname(req.file.originalname || "") || ".jpg";
  const finalName = `${req.file.filename}${ext}`;
  fs.renameSync(req.file.path, path.join(uploadDir, finalName));
  const imageUrl = `/uploads/radiology-key-images/${finalName}`;
  res.json({ success: true, item: { id: req.file.filename, imageUrl, thumbnailUrl: imageUrl, caption: req.body.caption || "", includeInReport: true } });
});
