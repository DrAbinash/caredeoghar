export const radiologyReportTemplates = {
  "MRI_BRAIN_PLAIN": {
    "templateId": "MRI_BRAIN_PLAIN",
    "modality": "MRI",
    "studyName": "MRI BRAIN",
    "technique": "MRI of brain has been performed on 3 Tesla MRI scanner with multi-sequence, multi-planar acquisition using standard T1, T2, FLAIR, DWI, ADC and SWI sequences and studied in axial, sagittal and coronal planes.",
    "sections": [
      "BRAIN PARENCHYMA",
      "VENTRICULAR SYSTEM / CSF SPACES",
      "POSTERIOR FOSSA",
      "MIDLINE STRUCTURES",
      "SELLAR / PARASELLAR REGION",
      "ORBITS / PNS / MASTOIDS"
    ]
  },
  "MRI_LS_SPINE": {
    "templateId": "MRI_LS_SPINE",
    "modality": "MRI",
    "studyName": "MRI LUMBOSACRAL SPINE",
    "technique": "MRI of lumbosacral spine has been performed on 3 Tesla MRI scanner with multi-sequence, multi-planar acquisition using standard sequences and studied in sagittal and axial planes.",
    "sections": [
      "ALIGNMENT & CURVATURE",
      "VERTEBRAL BODIES",
      "INTERVERTEBRAL DISCS",
      "SPINAL CANAL",
      "NEURAL FORAMINA",
      "CONUS / CAUDA EQUINA",
      "PARASPINAL SOFT TISSUES"
    ]
  },
  "CT_BRAIN": {
    "templateId": "CT_BRAIN",
    "modality": "CT",
    "studyName": "CT BRAIN",
    "technique": "Non-contrast CT brain has been performed with axial sections and multiplanar reconstruction.",
    "sections": [
      "CEREBRAL PARENCHYMA",
      "VENTRICULAR SYSTEM",
      "EXTRA-AXIAL SPACES",
      "POSTERIOR FOSSA",
      "BONES / SCALP"
    ]
  },
  "USG_ABDOMEN": {
    "templateId": "USG_ABDOMEN",
    "modality": "USG",
    "studyName": "ULTRASOUND WHOLE ABDOMEN",
    "technique": "Ultrasound examination of abdomen has been performed using curvilinear probe.",
    "sections": [
      "LIVER",
      "GALL BLADDER / CBD",
      "PANCREAS",
      "SPLEEN",
      "KIDNEYS",
      "URINARY BLADDER",
      "FREE FLUID"
    ]
  },
  "XRAY_CHEST_PA": {
    "templateId": "XRAY_CHEST_PA",
    "modality": "X-RAY",
    "studyName": "X-RAY CHEST PA VIEW",
    "technique": "Digital radiograph of chest has been obtained in PA projection.",
    "sections": [
      "LUNG FIELDS",
      "CARDIOMEDIASTINAL SILHOUETTE",
      "PLEURA",
      "BONES / SOFT TISSUES"
    ]
  }
};
