CREATE TABLE IF NOT EXISTS radiology_report_drafts (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  study_id TEXT,
  patient_id TEXT,
  template_id TEXT,
  modality TEXT,
  study_name TEXT,
  clinical_history TEXT,
  raw_findings TEXT,
  findings_sections JSONB DEFAULT '{}'::jsonb,
  impression JSONB DEFAULT '[]'::jsonb,
  recommendation TEXT,
  formatted_report_html TEXT,
  formatted_report_text TEXT,
  status TEXT DEFAULT 'DRAFT',
  created_by TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS radiology_voice_logs (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  study_id TEXT,
  patient_id TEXT,
  target_field TEXT,
  raw_transcript TEXT,
  cleaned_text TEXT,
  created_by TEXT,
  created_at TIMESTAMPTZ DEFAULT now()
);

CREATE TABLE IF NOT EXISTS radiology_report_key_images (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  study_id TEXT,
  report_draft_id UUID,
  patient_id TEXT,
  accession_number TEXT,
  study_instance_uid TEXT,
  image_url TEXT NOT NULL,
  thumbnail_url TEXT,
  caption TEXT,
  sort_order INTEGER DEFAULT 0,
  include_in_report BOOLEAN DEFAULT TRUE,
  source_type TEXT DEFAULT 'UPLOAD',
  created_by TEXT,
  created_at TIMESTAMPTZ DEFAULT now(),
  updated_at TIMESTAMPTZ DEFAULT now()
);
