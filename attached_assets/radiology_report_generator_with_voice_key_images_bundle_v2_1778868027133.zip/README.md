# Radiology Report Generator with Voice + Key Images

Replit ERP integration bundle for MRI/CT/USG/X-Ray report generation.

Includes:
- MRI / CT / USG / X-Ray template library
- Prompt-to-report builder
- Voice dictation integration
- Key image upload/selection and captions
- HTML report preview with key images
- Save to existing POST /api/patient-reports
- Word/PDF export hooks
- Manual mode + PACS worklist mode

Use REPLIT_INTEGRATION_COMMAND.txt for Replit Agent.
